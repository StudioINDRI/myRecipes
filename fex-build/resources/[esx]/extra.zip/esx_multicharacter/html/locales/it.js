const translate = new Object();

translate.name = "Nome";
translate.job = "Lavoro";
translate.bank = "Banca";
translate.money = "Contanti";
translate.gender = "Genere";
translate.dob = "Data di nascita";
