Locales['fi'] = {
  ['valid_purchase'] = 'varmista tämä ostos?',
  ['yes'] = 'kyllä',
  ['no'] = 'ei',
  ['not_enough_money'] = 'sinulla ei ole tarpeeksi rahaa',
  ['press_access'] = 'paina [E] avataksesi menu',
  ['barber_blip'] = 'Kampaamo',
  ['you_paid'] = 'sinä maksoit $%s',
}
