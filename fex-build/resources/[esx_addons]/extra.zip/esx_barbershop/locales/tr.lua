Locales['tr'] = {
	['valid_purchase'] = 'bu işlemi doğruluyor musun?',
	['yes'] = 'evet',
	['no'] = 'hayır',
	['not_enough_money'] = 'yeterli miktarda paranız yok',
	['press_access'] = 'Berbere erişmek için [E] basın',
	['barber_blip'] = 'berber',
	['you_paid'] = '$%s ödedin',
  }
