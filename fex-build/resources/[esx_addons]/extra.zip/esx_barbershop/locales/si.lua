Locales['si'] = {
  ['valid_purchase'] = 'potrdi ta nakup?',
  ['yes'] = 'da',
  ['no'] = 'no',
  ['not_enough_money'] = 'nimate dovolj denarja',
  ['press_access'] = 'pritisnite [E] za dostop do Barber Shop.',
  ['barber_blip'] = 'Frizerski Salon',
  ['you_paid'] = 'plačali ste $%s',
}
