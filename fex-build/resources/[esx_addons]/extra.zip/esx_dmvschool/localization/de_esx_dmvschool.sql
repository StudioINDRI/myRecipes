INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Probeführerschein'),
	('drive', 'Führerschein'),
	('drive_bike', 'Motorradschein'),
	('drive_truck', 'Lastkraftschein')
;
