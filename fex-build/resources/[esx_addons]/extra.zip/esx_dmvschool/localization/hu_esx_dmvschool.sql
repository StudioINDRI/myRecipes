

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Vezetési engedély'),
	('drive', 'Jogosítvány'),
	('drive_bike', 'Motoros Jogosítvány'),
	('drive_truck', 'Kereskedelmi Jogosítvány')
;
