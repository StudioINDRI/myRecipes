Locales['de'] = {
  ['new_job'] = 'Du hast einen neuen Job!',
  ['access_job_center'] = 'Drücke [E] um das Arbeitsamt zu öffnen.',
  ['job_center'] = 'Arbeitsamt',
  ["blip_text"] = "Job Center"

}
