Locales['fr'] = {
  ['new_job'] = 'vous avez un nouveau job !',
  ['access_job_center'] = 'appuyez sur ~INPUT_PICKUP~ pour \naccéder au Pôle Emploi.',
  ['job_center'] = 'pôle-Emploi',
}
