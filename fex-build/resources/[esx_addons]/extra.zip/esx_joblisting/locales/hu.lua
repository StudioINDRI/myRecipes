Locales['hu'] = {
  ['new_job'] = 'Felvetted a munkát!',
  ['access_job_center'] = 'Nyomj ~INPUT_PICKUP~ hogy megnézd a munkákat',
  ['job_center'] = 'Munkaügyi központ',
}
