Locales['nl'] = {
  ['new_job'] = 'Nieuwe baan: ~b~%s~s~ !',
  ['access_job_center'] = 'Klik op ~b~[E]~s~ om het uitzendbureau te openen.',
  ['job_center'] = 'Selecteer een baan.',
  ["blip_text"] = "Uitzendbureau"
}
