Locales['it'] = {
  ['new_job'] = 'Nuovo lavoro: ~b~%s~s~ !',
  ['access_job_center'] = 'Premi ~b~[E]~s~ per aprire la scelta dei lavori.',
  ['job_center'] = 'Seleziona un lavoro.',
  ["blip_text"] = "Centro lavori"
}
