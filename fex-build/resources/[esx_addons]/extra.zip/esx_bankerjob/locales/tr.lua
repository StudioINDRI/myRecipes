Locales['tr'] = {
    ['actions']                           = 'hareketler',
    ['amount']                            = 'tutar',
    ['balance']                           = 'bakiye',
    ['bank']                              = 'banka',
    ['bill_amount']                       = 'fatura tutarı',
    ['billing']                           = 'faturalandırma',
    ['customer']                          = 'müşteri',
    ['customers']                         = 'müşteriler',
    ['deposit']                           = 'para yatır',
    ['invalid_amount']                    = 'geçersiz tutar',
    ['no_player_nearby']                  = 'yakında oyuncu yok',
    ['press_input_context_to_open_menu']  = 'Banka Menüsünü açmak için [E] tuşuna basın.',
    ['withdraw']                          = 'para çek',
    ['boss_actions']                      = 'patron Hareketleri',
    ['phone_receive']                     = 'banka Müşterisi',
    ['phone_label']                       = 'banka',
  }
  