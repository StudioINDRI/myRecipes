Locales['si'] = {
  ['shop'] = 'shop',
  ['shops'] = 'shops',
  ['press_menu'] = "pritisnite [E] za dostop do store.",
  ['shop_item'] = '$%s',
  ['bought'] = 'pravkar ste kupili %sx %s za ~r~$%s',
  ['not_enough'] = 'nimaš ~r~enough denarja, missing ~r~$%s!',
  ['player_cannot_hold'] = 'v svojem inventarju nimaš dovolj prostega prostora!',
  ['shop_confirm'] = 'kupi %sx %s za $%s?',
  ['no'] = 'ne',
  ["yes"] = "yes",
}
