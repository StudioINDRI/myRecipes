Locales['pl'] = {
  ['shop'] = 'sklep',
  ['shops'] = 'sklepy',
  ['press_menu'] = 'naciśnij [E] żeby wejść do sklepu.',
  ['shop_item'] = '$%s',
  ['bought'] = 'właśnie zakupiłeś %s x %s za %s $',
  ['not_enough'] = 'nie masz ~r~wystarczjąco pięniędzy, Brakuje Ci ~r~$%s!',
  ['player_cannot_hold'] = '~r~Nie masz wystarczająco wolnego miejsca w swoim ekwipunku!',
  ['shop_confirm'] = 'chcesz kupić %sx %s za $%s?',
  ['no'] = 'nie',
  ['yes'] = 'tak',
}
