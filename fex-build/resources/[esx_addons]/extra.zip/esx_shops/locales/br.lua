Locales['br'] = {
  ['shop'] = 'comprar',
  ['shops'] = 'lojas',
  ['press_menu'] = 'pressione [E] para acessar a loja.',
  ['shop_item'] = '$%s',
  ['bought'] = 'você acabou de comprar %sx %s por ~r~$%s',
  ['not_enough'] = 'você não tem ~r~dinheiro suficiente: %s',
  ['player_cannot_hold'] = 'você ~r~não tem bastante espaço livre no seu inventário!',
  ['shop_confirm'] = 'comprou %sx %s por $%s?',
  ['no'] = 'não',
  ['yes'] = 'sim',
}
