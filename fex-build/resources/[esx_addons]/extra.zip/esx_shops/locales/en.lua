Locales['en'] = {
  ['shop'] = 'shop',
  ['shops'] = 'shops',
  ['press_menu'] = 'press [E] to access the ~g~store.',
  ['shop_item'] = '$%s',
  ['bought'] = 'You Have Bought ~b~%sx %s~s~ for ~b~$%s',
  ['not_enough'] = 'you do ~r~not~s~ have enough money, you\'re missing ~b~$%s!',
  ['player_cannot_hold'] = 'you do ~r~not~s~ have enough free space in your inventory!',
  ['shop_confirm'] = 'buy %sx %s for $%s?',
  ['no'] = 'no',
  ['yes'] = 'yes',
}
