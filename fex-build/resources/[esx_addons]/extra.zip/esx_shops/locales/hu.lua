Locales['hu'] = {
  ['shop'] = 'Bolt',
  ['shops'] = 'Bolt',
  ['press_menu'] = 'Nyomd meg a [E] gombot hogy megnézd a kinálatot',
  ['shop_item'] = '%s$',
  ['bought'] = 'Vettél %sx %s ennyiért: ~r~$%s',
  ['not_enough'] = 'Nincsen elég pénzed',
  ['player_cannot_hold'] = 'Nincsen elég szabad helyed!',
  ['shop_confirm'] = 'Veszel %sx %s ennyiért $%s?',
  ['no'] = 'Nem',
  ['yes'] = 'Igen',
}
