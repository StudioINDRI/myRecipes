Locales['sv'] = {
  ['shop'] = 'affär',
  ['shops'] = 'affärer',
  ['press_menu'] = 'tryck [E] för att handla prylar.',
  ['shop_item'] = '%s SEK',
  ['bought'] = 'du har köpt %sx %s för ~r~%s SEK',
  ['not_enough'] = 'du har inte ~r~tillräckligt med pengar, det saknas ~r~%s SEK!',
  ['player_cannot_hold'] = 'du har ~r~inte tillräckligt med utrymme för att hålla det!',
  ['shop_confirm'] = 'köpa %sx %s för %s SEK?',
  ['no'] = 'nej',
  ['yes'] = 'ja',
}
