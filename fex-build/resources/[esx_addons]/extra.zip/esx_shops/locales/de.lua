Locales['de'] = {
  ['shop'] = 'geschäft',
  ['shops'] = 'geschäfte',
  ['press_menu'] = 'Drücke [E] um auf das Geschäft zuzugreifen.',
  ['shop_item'] = '$%s',
  ['bought'] = 'Du kaufst %sx %s für $%s',
  ['not_enough'] = 'Du hast nicht genug geld: %s',
  ['player_cannot_hold'] = 'Du hast nicht genug Platz in deinem Inventar',
  ['shop_confirm'] = 'Kaufe %sx %s für $%s?',
  ['no'] = 'nein',
  ['yes'] = 'ja',
}
