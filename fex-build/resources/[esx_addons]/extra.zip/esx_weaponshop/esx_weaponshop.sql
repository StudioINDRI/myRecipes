INSERT INTO `licenses` (`type`, `label`) VALUES
	('weapon', "Weapon licence")
;
