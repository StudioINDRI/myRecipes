<h1 align='center'>[ESX] Weapon Shops</a></h1><p align='center'><b><a href='https://discord.esx-framework.org/'>Discord</a> - <a href='https://esx-framework.org/'>Website</a> - <a href='https://docs.esx-framework.org/legacy/installation'>Documentation</a></b></h5>

Would it be Los-Santos Without some weapons? No! This resource lets Players spend their hard earned drug money on buying the important things in life - revolvers and RPGs! Users can goto their trusty Ammu-Nation to get some Legal fun or get risky and frisky with the illegal black-market dealer 😉

# Legal

esx_weaponshop - America Simulator!

Copyright (C) 2015-2022 Jérémie N'gadi

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.