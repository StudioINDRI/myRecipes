Locales['si'] = {
  ['valid_this_purchase'] = 'potrdi ta nakup?',
  ['yes'] = 'da',
  ['no'] = 'no',
  ['not_enough_money'] = 'nimate dovolj denarja',
  ['press_menu'] = 'pritisnite [E] za dostop do Clothing Shop.',
  ['clothes'] = 'trgovina z oblačili',
  ['you_paid'] = 'plačal si $%s',
  ['save_in_dressing'] = 'ali želite oblačila shraniti v svojo lastnino?',
  ['name_outfit'] = 'poimenuj svojo obleko',
  ['saved_outfit'] = 'obleka je shranjena!',
}
