Locales['nl'] = {
  ['valid_this_purchase'] = 'bevestig deze aankoop?',
  ['yes'] = 'ja',
  ['no'] = 'nee',
  ['not_enough_money'] = 'je hebt niet genoeg geld',
  ['press_menu'] = 'klik op [E] om de kleding winkel te bezoeken.',
  ['clothes'] = 'kleding winkel',
  ['you_paid'] = 'je betaalde $%s',
  ['save_in_dressing'] = 'wil je deze outfit opslaan in je garderobe?',
  ['name_outfit'] = 'geef je outfit een naam',
  ['saved_outfit'] = 'je outfit is opgeslagen.',
}
